blocked_names = {
    'eval',
    'exec',
    'import',
    'os',
    'sys',
    'subprocess',
    'sh',
    'bash',
    'shell',
    'flag',
    'homecooked',
    'homecookedconfig'
}